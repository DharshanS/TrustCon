<?php
/**
 * Created by PhpStorm.
 * User: me664
 * Date: 3/3/15
 * Time: 8:35 AM
 */
$lang['More']=__('More','traveler');
$lang['Less']=__('Less','traveler');
$lang['s_review']=__('%d review','traveler');
$lang['s_reviews']=__('%d reviews','traveler');
$lang['d_to_d']=__('%d to %d','traveler');
$lang['Name*']=__('Name*','traveler');
$lang['leave_a_review']=__('Leave a Review','traveler');
$lang['pingback']=__('Pingback:','traveler');
$lang['edit']=__('Edit','traveler');
$lang['your_comment_need_approved']=__('Your comment is awaiting moderation.','traveler');
$lang['_ago']=__(' ago','traveler');
$lang['1_comment']=__('1 comment','traveler');
$lang['0_comment']=__('no comment','traveler');
$lang['s_comment']=__('% comments','traveler');
$lang['you_are_booking_for_s']=__('You are booking for %s','traveler');
$lang['photos']=__('Photos','traveler');
$lang['on_the_map']=__('On the Map','traveler');
$lang['video']=__('Video','traveler');
$lang['owner_description']=__('Owner description','traveler');
$lang['activity_reviews']=__('Activity Reviews','traveler');
$lang['to']=__('to','traveler');
$lang['paypal']=__('Paypal','traveler');
$lang['captcha']=__('Captcha','traveler');
$lang['now_s_users_seeing_this_s']=__('Now %d user(s) seeing this %s','traveler');
$lang['most_revent_booking_for_this_s_was_s']=__('Most recent booking for this %s was %s','traveler');

