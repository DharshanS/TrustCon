<?php
//ST blog
 $lang['read_more']=__('Read More','traveler');
//ST Slide loaction
 $lang['explore']=__('Explore','traveler');
 $lang['from']=__('From','traveler');
 $lang['hotels_from']=__('Hotels from','traveler');
 $lang['rentals_from']=__('Rentals from','traveler');
 $lang['cars_from']=__('Cars from','traveler');
 $lang['tours_from']=__('Tours from','traveler');
 $lang['activities_this_week']=__('Activities this Week','traveler');
 $lang['night']=__('night','traveler');
 $lang['day']=__('day','traveler');
 $lang['person']=__('person','traveler');
 $lang['last_minute_deal']=__('Last Minute Deal','traveler');

