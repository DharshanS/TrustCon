<?php
// User create car
$lang['user_create_car'] = __('Create Car','traveler');
$lang['user_create_car_title'] = __('Title','traveler');
$lang['user_create_car_content'] = __('Content','traveler');
$lang['user_create_car_description'] = __('Description','traveler');
$lang['user_create_car_featured_image'] = __('Featured Image','traveler');
$lang['user_create_car_detail'] = __('Car Detail','traveler');
$lang['user_create_car_category'] = __('Category Car','traveler');
$lang['user_create_car_pickup_features'] = __('Pickup Features','traveler');
$lang['user_create_car_equipment_price_list'] = __('Equipment Price List','traveler');
$lang['user_create_car_add_equipment'] = __('Add Equipment','traveler');
$lang['user_create_car_features'] = __('Features','traveler');
$lang['user_create_car_add_features'] = __('Add Features','traveler');
$lang['user_create_car_video'] = __('Video','traveler');
$lang['user_create_car_car_contact'] = __('Car Contact','traveler');
$lang['user_create_car_logo'] = __('Logo','traveler');
$lang['user_create_car_name'] = __('Name','traveler');
$lang['user_create_car_email'] = __('Email','traveler');
$lang['user_create_car_phone'] = __('Phone','traveler');
$lang['user_create_car_about'] = __('About','traveler');
$lang['user_create_car_location'] = __('Location','traveler');
$lang['user_create_car_location_search'] = __('Location search','traveler');
$lang['user_create_car_address'] = __('Address','traveler');
$lang['user_create_car_price'] = __('Price','traveler');
$lang['user_create_car_discount'] = __('Discount','traveler');
$lang['user_create_car_submit'] = __('SUBMIT','traveler');
$lang['user_create_car_equipment_title'] = __('Title','traveler');
$lang['user_create_car_equipment_price'] = __('Price','traveler');
$lang['user_create_car_del'] = __('Del','traveler');
$lang['user_create_car_features_attributes'] = __('Attributes','traveler');
$lang['user_create_car_features_attributes_info'] = __('Attributes Info','traveler');
$lang['user_create_car_no_data'] = __('No data','traveler');



