<?php
$lang['cruise']=__('Cruise','traveler');
$lang['cruise_adults_occupancy']=__('Adults Occupancy','traveler');
$lang['cruise_childs']=__('Childs','traveler');
$lang['cruise_bebs']=__('Beds','traveler');
$lang['cruise_room_footage']=__('Room footage (square feet)','traveler');
