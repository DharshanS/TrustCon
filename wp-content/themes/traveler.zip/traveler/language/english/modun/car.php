<?php
$lang["car"]=__("Car","traveler");
$lang["cars"]=__("Cars","traveler");
//search-form.php
$lang['search_for_cars']=__('Search for Cars','traveler');
$lang['change_for_cars']=__('Change for Cars','traveler');
$lang['change_location_and_date']=__('Change Location &amp; Date','traveler');

//Post type

$lang['car_pickup_features']=__('Pickup Features','traveler');
$lang['car_search_pickup_features']=__('Search Pickup Features','traveler');

//search-form.php
$lang["search_for_cars"]=__("Search for Cars","traveler");
//filter.php
$lang["car_filter"]=__("Filter","traveler");
$lang["car_filter_by"]=__("Filter By","traveler");

$lang["car_sort"]=__("Sort","traveler");
$lang["car_showing"]=__("Showing","traveler");
$lang["car_not_what_you_looking_for"]=__("Not what you're looking for? ","traveler");
$lang["car_try_your_search_again"]=__("Try your search again","traveler");
// cart_item_html
// cart_item_html
$lang["car_day"]=__("day","traveler");
$lang["car_days"]=__("days","traveler");
$lang["car_for"]=__("Car for","traveler");
$lang["car_due_at_pick_up"]=__("Due at pick-up","traveler");
$lang["car_passengers"]=__("Passengers","traveler");
$lang["car_passenger"]=__("Passenger","traveler");
$lang["car_equipment"]=__("Equipment","traveler");
// element/price
$lang['car_price_per']=__('Price Per','traveler');
$lang['car_rental_price']=__('Rental Price','traveler');
$lang['car_rental_total']=__('Rental Total',"traveler");
//field-pick-up-form.php
$lang['car_city_airport_or_us_zip_code']=__('City, Airport or U.S. Zip Code',"traveler");
$lang['car_select']=__("Select",'traveler');
$lang['car_price']=__("Price",'traveler');
$lang['car_book_now']=__("Book Now",'traveler');

$lang['car_not_set_layout'] = __("Not set default layout !","traveler");
$lang['car_email'] = __("E-mail Car Agent","traveler");
$lang['car_total'] = __("Total","traveler");

$lang['car_pick_up'] = __("Pick Up","traveler");
$lang['car_drop_off'] = __("Drop Off","traveler");
$lang['car_about'] = __("About","traveler");
$lang['car_phone'] = __("Phone","traveler");
$lang['car_email'] = __("Email","traveler");
$lang['car_number'] = __('Number','traveler');
$lang['driver_age'] = __('Driver’s Age','traveler');
$lang['driver_name'] = __('Driver’s Name','traveler');
$lang['driver_info'] = __('Driver info','traveler');