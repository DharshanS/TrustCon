<?php 
 $lang["activity"]=__("Activity","traveler");
 $lang["activities"]=__("Activities","traveler");
//search-form.php
 $lang["search_for_activity"]=__("Search for Activity","traveler");
//filter.php
 $lang["filter"]=__("Filter","traveler");
 $lang["filter_by"]=__("Filter By","traveler");
//content-activity.php
 $lang["sort"]=__("Sort","traveler");
 $lang["showing"]=__("Showing","traveler");
 $lang["not_what_you_looking_for"]=__("Not what you're looking for? ","traveler");
 $lang["try_your_search_again"]=__("Try your search again","traveler");
// cart_item_html
 $lang["sorry_activity_not_found"]=__("Sorry!. Activity Not Found","traveler");
 $lang["event"]=__("Event","traveler");
 $lang["guests"]=__("Guests","traveler");
 $lang["price"]=__("Price","traveler");
 $lang["total"]=__("Total","traveler");
//element/review_summary
 $lang["clean"]=__("Clean","traveler");
 $lang["good"]=__("Good","traveler");
 $lang["very_good"]=__("Very good","traveler");
 $lang["superior"]=__("Superior","traveler");
 $lang["exceptional"]=__("Exceptional","traveler");
 $lang["of_guests_recommend"]=__("of guests recommend","traveler");
//element/review_detail
 $lang["traveler_rating"]=__("Traveler rating","traveler");
 $lang["exellent"]=__("Excellent","traveler");
 $lang["average"]=__("Average","traveler");
 $lang["poor"]=__("Poor","traveler");
 $lang["terrible"]=__("Terrible","traveler");
 $lang["write_a_review"]=__("Write a Review","traveler");
 $lang["summary"]=__("Summary","traveler");
//element/nearby.php
 $lang["activity_near"]=__("Activity Near","traveler");
 $lang["activities_near"]=__("Activities Near","traveler");
//element/form-book.php
 $lang["activity_time"]=__("Activity Time","traveler");
 $lang["duration"]=__("Duration","traveler");
 $lang["availability"]=__("Availability","traveler");
 $lang["venue_facilities"]=__("Venue Facilities","traveler");
 $lang["book_now"]=__("Book Now","traveler");
 $lang["best_price_guarantee"]=__("Best Price Guarantee","traveler");
//element/search/field-address.php
 $lang["activity_or_us_zip_code"]=__("Activity or U.S. Zip Code","traveler");
//element/loop-x.php
 $lang["1_review"]=__("1 review","traveler");
 $lang["reviews"]=__("reviews","traveler");
 $lang["date"]=__("Date","traveler");
 $lang["from"]=__("from","traveler");
 $lang["of"]=__("of","traveler");

$lang["activity_email"]=__("E-mail Activity Agent","traveler");
$lang["activity_website"]=__("Owner Website","traveler");
$lang["activity_price"]=__("Price","traveler");
$lang['activity_not_set_layout'] = __("Not set default layout !","traveler");



