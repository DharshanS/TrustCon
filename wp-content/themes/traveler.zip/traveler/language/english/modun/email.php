<?php
/**
 * Created by PhpStorm.
 * User: me664
 * Date: 3/3/15
 * Time: 9:41 AM
 */
$lang['booking_infomation']=__('Booking Information','traveler');
$lang['item']=__('Item','traveler');
$lang['infomation']=__('Informtion','traveler');
$lang['sub_total']=__('Sub Total','traveler');
$lang['tax']=__('Tax','traveler');
$lang['total']=__('Total','traveler');
$lang['customer_infomation']=__('Total','traveler');
$lang['confirmation_needed']=__('Confirmation needed','traveler');
$lang['you_added_an_email_to_your_account']=__('You added an email address to your account','traveler');
$lang['click_confirm_to_import_the_booking']=__('Click "confirm" to import the bookings you\'ve made with that address','traveler');
$lang['email_confirm']=__('Confirm','traveler');
$lang['email_can_see_the_button']=__('Can\'t see the button? Try this link:','traveler');