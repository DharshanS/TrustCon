<?php
// User create cruise
$lang['user_create_hotel'] = __('Create hotel','traveler');
$lang['user_create_hotel_title'] = __('Title','traveler');
$lang['user_create_hotel_content'] = __('Content','traveler');
$lang['user_create_hotel_description'] = __('Description','traveler');

$lang['user_create_hotel_featured_image'] = __('Featured Image','traveler');
$lang['user_create_hotel_detail'] = __('Hotel Detail','traveler');
$lang['user_create_hotel_attributes'] = __('Attributes','traveler');
$lang['user_create_hotel_email'] = __('Hotel Email','traveler');
$lang['user_create_hotel_website'] = __('Hotel Website','traveler');
$lang['user_create_hotel_phone'] = __('Hotel Phone','traveler');
$lang['user_create_hotel_fax_number'] = __('Fax Number','traveler');
$lang['user_create_hotel_video'] = __('Video','traveler');

$lang['user_create_hotel_search'] = __('Search','traveler');
$lang['user_create_hotel_location'] = __('Location','traveler');
$lang['user_create_hotel_address'] = __('Address','traveler');
$lang['user_create_hotel_latitude'] = __('Latitude','traveler');
$lang['user_create_hotel_longitude'] = __('Longitude','traveler');
$lang['user_create_hotel_map_zoom'] = __('Map Zoom','traveler');
$lang['user_create_hotel_logo'] = __('Logo','traveler');
$lang['user_create_hotel_gallery'] = __('Gallery','traveler');
$lang['user_create_hotel_submit'] = __('SUBMIT','traveler');



