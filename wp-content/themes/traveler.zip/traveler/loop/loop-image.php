<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Single loop image
 *
 * Created by ShineTheme
 *
 */
?>
<a class="hover-img" href="<?php the_permalink()?>">
    <?php the_post_thumbnail() ?><i class="fa fa-link box-icon-# hover-icon round"></i>
</a>