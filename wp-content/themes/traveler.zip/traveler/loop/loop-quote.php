<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Single loop quote
 *
 * Created by ShineTheme
 *
 */
?>
<blockquote><?php the_excerpt()?></blockquote>