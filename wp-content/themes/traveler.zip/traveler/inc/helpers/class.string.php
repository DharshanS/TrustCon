<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Class STString
 *
 * Created by ShineTheme
 *
 */

class STString
{

    function remove_wpautop($string)
    {

    }

}