<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Redirect to home
 *
 * Created by ShineTheme
 *
 */
wp_safe_redirect(home_url());
get_header();